//import React from "react";
import React, { useState, useEffect } from "react";

function Pedidos_DashBoard(){
    
    


    //logica de token
    const isAuthenticated = localStorage.getItem('token');

    //debido a que es la ventana principal, solamente cambia el
    //boton de Iniciar o Cerrar Sesion.

    //log out
    const logOut = () => {
        alert("Sesion cerrada.")
        window.location.href = '/';
        //esto destruye el token
        localStorage.removeItem('token')
    };

    var botonSesion = "Cerrar";
    //preguntamos si tiene el token de inicio de sesion.
    if(!isAuthenticated)
        //console.log('token given!')
        window.location.href = '/';
    
    //debido a que es la ventana principal, solamente cambia el
    //boton de Iniciar o Cerrar Sesion.

    return(
        <>

        <nav class="barraNavegacion">
            <a href="/">Inicio</a>
            <a href="/pedidos">Pedidos</a>
            <a href="#" onClick={logOut}>{botonSesion} Sesión</a>
        </nav>

        <div class="contenedorIndex">
        <h1>Pagina de Pedidos</h1>
        <p>Esta es la pagina de Pedidos</p>
        </div>

        
        <table class="tablaUsuarios">
                    <thead>       
                        <tr>
                            <th>Numero Pedido</th>
                            <th>Articulos</th>
                            <th>Notas</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/*userData.map((user) => (
                            <>
                            <tr class="filaUsers" key={user.user}>
                                <td>{user.user}</td>
                                <td>{user.passw}</td>
                                <td class="optionButtons">
                                    <button class="botonModificar" > <span>Modificar</span> </button>
                                    <button class="botonEliminar" > <span>Eliminar</span> </button>
                                </td>
                            </tr>
                            
                            </>
                        ))
                        */}
                    </tbody>
            </table>

        </>
    );
}

export default Pedidos_DashBoard;