import React, { useState } from 'react';
const bcrypt = require('bcryptjs');
const saltRounds = 10; // Number of salt rounds for bcrypt hashing

const RegisterUser = () => {

    const [formData, setFormData] = useState({
        user: '',
        passw: ''
    });

    const handleInputChange = (event) => {
        const { id, value } = event.target;
        setFormData({ ...formData, [id]: value });
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {

            // Hash the password
            const hashedPassword = await bcrypt.hash(formData.passw, saltRounds);
            formData.passw = hashedPassword;

            const response = await fetch('http://localhost:3001/insertUser', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                if(response.status === 201){
                    alert('Este usuario ya existe.')
                }
                else{
                    alert('Registro correcto!');
                }
            } else {
                alert('Hubo un error al registrarse. Intente mas tarde.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Hubo un error al registrarse. Intente mas tarde.');
        }
    };

    const showPassword = () => {
        var passwordInput = document.getElementById('passw');
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
        } else {
            passwordInput.type = 'password';
        }
        
    };

    const returntoLogin = () => {
        window.location = '/';
    }

    

    return (
        <div class="contenedorRegistroUser">
            
            <form onSubmit={handleSubmit}>
                <h1>Registrarse</h1>
                <div>
                <input placeholder="Usuario" type="text" id="user" user="user" value={formData.user} onChange={handleInputChange} required />
                <button style={{visibility:'hidden'}} ></button>
                </div>

                <div>
                <input placeholder="Contraseña" type="password" id="passw" user="passw" value={formData.passw} onChange={handleInputChange} required />
                <button class="botonMostrarPW" type="button" onClick={showPassword}></button>
                </div>

                <button class="commonButton" type="submit">Registrarse</button>
                <br></br>
                <button class="regresaraLogin" type="button" onClick={returntoLogin}>Cancelar</button>
            </form>
        </div>
    );
};

export default RegisterUser;
