// Login.js
import React, { useState } from 'react';
import axios from 'axios';

function Login() {
  const [user, setUsername] = useState('');
  const [passw, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async () => {

    try {

      if (user == '' || passw == ''){
        return window.alert('Falta llenar alguno de los campos.');
      }

      const response = await axios.post('http://localhost:3001/login', {
        user,
        passw,
      });
      //genera un Token al iniciar sesion
      localStorage.setItem('token', response.token);

      if (response && response.data) {
        //setMessage(response.data.message);
        window.alert('Inicio de sesion correcto!');
        return window.location.href = '/dashboard'; }
        
      else {setMessage('Error: Respuesta inválida del servidor');}
    } catch (error) { setMessage(error.response.data.message); }
  };

  const gotoRegister = () => {
    window.location.href = '/register'
  };

  const gotoMain = () => {
    window.location.href='/';
  }
  
  /*Agregar despues:
  Al entrar al sitio web se haga un auto click en Usuario.*/
  return (
    <div className="contenedorLogin">
      <div>
        <h1>Ingrese sus datos.</h1>
        <input
          id='inputUsuario'
          type="text"
          placeholder="Usuario"
          value={user}
          onChange={(e) => setUsername(e.target.value)}
        />
        <br />
        <input
          type="password"
          placeholder="Contraseña"
          value={passw}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />
        <button className="commonButton" onClick={handleLogin}>Iniciar sesión</button>
        <br></br>
        <span>No tienes cuenta?</span>
        <br></br>
        <button className="commonButton" onClick={gotoRegister}>Registrarse</button>
        <br></br>
        <button className='commonButton' onClick={gotoMain}>Cancelar</button>
        <p>{message}</p>
      </div>
    </div>
  );
}

export default Login;